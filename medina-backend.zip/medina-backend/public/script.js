
const API_URL =
  location.port === "3000" ? "/api" : "http://localhost:3000/api";

const $ = id => document.getElementById(id);

const carSel = $("car");
const grid = $("grid");
const filters = $("filters");

let CARS = [];
let cats = ["Tous"];
let cat = "Tous";

const carSvg = `
<svg viewBox="0 0 240 90" fill="none" aria-hidden="true">
  <path d="M12 62c0-9 3-14 12-16l30-6c10-12 24-20 44-20h30c14 0 26 7 36 20l36 8c10 2 16 8 16 16v6H12z"
        fill="currentColor"/>
  <path d="M78 38c8-9 17-14 30-14h22v16H70zm62-14h12c9 0 17 6 24 16h-36z"
        fill="#fff" opacity=".85"/>
  <circle cx="62" cy="68" r="14" fill="#10202a"/>
  <circle cx="62" cy="68" r="6" fill="#aab8bf"/>
  <circle cx="182" cy="68" r="14" fill="#10202a"/>
  <circle cx="182" cy="68" r="6" fill="#aab8bf"/>
</svg>`;

// Animation : apparition au défilement
const revealObserver = "IntersectionObserver" in window
  ? new IntersectionObserver((entries, obs) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("in");
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 })
  : null;

function reveal(elements) {
  [...elements].forEach((el, i) => {
    if (!revealObserver) return;
    el.classList.add("reveal");
    el.style.setProperty("--d", `${Math.min(i, 8) * 0.07}s`);
    revealObserver.observe(el);
  });
}

function showMessage(element, message, success = false) {
  element.style.display = "block";
  element.textContent = message;
  element.style.background = success ? "#edf7ee" : "#fff0f0";
  element.style.color = success ? "#246b35" : "#a12626";
}

async function apiRequest(url, options = {}) {
  const response = await fetch(url, options);

  let data;
  try {
    data = await response.json();
  } catch {
    throw new Error("Réponse invalide du serveur.");
  }

  if (!response.ok) {
    throw new Error(data.message || "Une erreur est survenue.");
  }

  return data;
}

// 1. Charger les voitures depuis SQLite
async function fetchCars() {
  try {
    const data = await apiRequest(`${API_URL}/cars`);

    if (!Array.isArray(data)) {
      throw new Error("Format des voitures invalide.");
    }

    CARS = data;

    carSel.replaceChildren();

    if (CARS.length === 0) {
      carSel.add(new Option("Aucune voiture disponible", ""));
      grid.textContent = "Aucune voiture disponible.";
      calc();
      return;
    }

    CARS.forEach((car, index) => {
      carSel.add(
        new Option(
          `${car.name} – ${car.price} DT/jour`,
          String(index)
        )
      );
    });

    cats = [
      "Tous",
      ...new Set(CARS.map(car => car.type))
    ];

    drawFilters();
    drawCars();
    calc();
  } catch (error) {
    console.error("Erreur de chargement :", error);
    grid.textContent =
      "Impossible de charger les voitures. Vérifiez le serveur.";
    carSel.replaceChildren(
      new Option("Erreur de chargement", "")
    );
  }
}

// 2. Afficher les filtres
function drawFilters() {
  filters.replaceChildren();

  cats.forEach(type => {
    const button = document.createElement("button");

    button.type = "button";
    button.className = "chip";
    button.textContent = type;
    button.setAttribute(
      "aria-pressed",
      String(type === cat)
    );

    button.addEventListener("click", () => {
      cat = type;
      drawFilters();
      drawCars();
    });

    filters.appendChild(button);
  });
}

// 3. Afficher les voitures
function drawCars() {
  grid.replaceChildren();

  const visibleCars = CARS
    .map((car, index) => ({ car, index }))
    .filter(({ car }) =>
      cat === "Tous" || car.type === cat
    );

  if (visibleCars.length === 0) {
    grid.textContent = "Aucune voiture dans cette catégorie.";
    return;
  }

  visibleCars.forEach(({ car, index }) => {
    const article = document.createElement("article");
    article.className = "car";

    const pic = document.createElement("div");
    pic.className = "pic";
    pic.style.setProperty("--c", car.color || "#2678a5");
    const photo = document.createElement("img");
    photo.src = `images/car-${car.id}.jpg`;
    photo.alt = car.name;
    photo.loading = "lazy";
    photo.addEventListener("error", () => {
      pic.replaceChildren();
      pic.innerHTML = carSvg;
    }, { once: true });
    pic.appendChild(photo);

    const body = document.createElement("div");
    body.className = "body";

    const title = document.createElement("h3");
    title.textContent = car.name;

    const specs = document.createElement("p");
    specs.className = "specs";
    specs.textContent = `${car.type} · ${car.specs}`;

    const price = document.createElement("div");
    price.className = "price";

    const priceText = document.createElement("span");
    const strong = document.createElement("b");
    strong.textContent = `${car.price} DT`;

    const small = document.createElement("small");
    small.textContent = " /jour";

    priceText.append(strong, small);

    const button = document.createElement("button");
    button.className = "alt";
    button.type = "button";
    button.dataset.i = String(index);
    button.textContent = "Réserver";

    price.append(priceText, button);
    body.append(title, specs, price);
    article.append(pic, body);
    grid.appendChild(article);
  });

  reveal(grid.children);
}

// 4. Cliquer sur Réserver
grid.addEventListener("click", event => {
  const button = event.target.closest("button[data-i]");

  if (!button) return;

  carSel.value = button.dataset.i;
  calc();

  $("resa").scrollIntoView({
    behavior: "smooth",
    block: "center"
  });

  $("d1").focus({ preventScroll: true });
});

// 5. Initialiser les dates
function localISODate(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
}

const today = new Date();
const threeDaysLater = new Date(today);
threeDaysLater.setDate(threeDaysLater.getDate() + 3);

$("d1").min = localISODate(today);
$("d1").value = localISODate(today);

$("d2").min = localISODate(today);
$("d2").value = localISODate(threeDaysLater);

// 6. Calculer le nombre de jours
function nbDays() {
  const start = $("d1").value;
  const end = $("d2").value;

  if (!start || !end) return 0;

  const a = Date.parse(start + "T00:00:00Z");
  const b = Date.parse(end + "T00:00:00Z");

  if (!Number.isFinite(a) || !Number.isFinite(b)) {
    return 0;
  }

  return Math.round((b - a) / 86400000);
}

// 7. Calculer le prix total
function calc() {
  const index = Number(carSel.value);
  const car = CARS[index];
  const days = nbDays();

  if (!car || !Number.isFinite(Number(car.price))) {
    $("days").textContent = "Choisissez une voiture";
    $("sum").textContent = "0 DT";
    return 0;
  }

  if (days < 1) {
    $("days").textContent =
      "La date de retour doit être après le départ.";
    $("sum").textContent = "0 DT";
    return 0;
  }

  $("days").textContent =
    `${days} jour${days > 1 ? "s" : ""} × ${car.price} DT`;

  const sum = $("sum");
  const newTotal = `${days * Number(car.price)} DT`;

  if (sum.textContent !== newTotal) {
    sum.textContent = newTotal;
    sum.classList.remove("bump");
    void sum.offsetWidth;
    sum.classList.add("bump");
  }

  return days;
}

// Ajuster la date de retour
$("d1").addEventListener("change", () => {
  $("d2").min = $("d1").value;

  if ($("d2").value <= $("d1").value) {
    const next = new Date($("d1").value + "T00:00:00");
    next.setDate(next.getDate() + 1);
    $("d2").value = localISODate(next);
  }

  calc();
});

["car", "d1", "d2"].forEach(id => {
  $(id).addEventListener("change", calc);
});

// 8. Enregistrer une réservation
$("resa").addEventListener("submit", async event => {
  event.preventDefault();

  const ok = $("ok");
  ok.style.display = "block";

  const days = calc();
  const car = CARS[Number(carSel.value)];

  if (!car) {
    showMessage(ok, "Veuillez choisir une voiture.");
    return;
  }

  if (days < 1) {
    showMessage(
      ok,
      "La date de retour doit être après la date de départ."
    );
    return;
  }

  const name = $("name").value.trim();
  const phone = $("tel").value.trim();

  if (!name || name.length > 100) {
    showMessage(ok, "Veuillez saisir votre nom.");
    return;
  }

  if (!/^[0-9+\s()-]{8,20}$/.test(phone)) {
    showMessage(ok, "Numéro de téléphone invalide.");
    return;
  }

  const submitButton = event.submitter;
  if (submitButton) submitButton.disabled = true;

  try {
    const data = await apiRequest(
      `${API_URL}/reservations`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          car_id: car.id,
          city: $("city").value,
          start_date: $("d1").value,
          end_date: $("d2").value,
          client_name: name,
          phone,
          total_price: days * Number(car.price)
        })
      }
    );

    showMessage(
      ok,
      `Réservation #${data.reservationId} enregistrée ! ` +
      `${car.name}, ${data.days} jour(s), ` +
      `${data.total_price} DT. Nous vous appelons pour confirmer.`,
      true
    );
  } catch (error) {
    showMessage(ok, error.message);
    console.error("Erreur de réservation :", error);
  } finally {
    if (submitButton) submitButton.disabled = false;
  }
});

// 9. Envoyer un message de contact
$("msg").addEventListener("submit", async event => {
  event.preventDefault();

  const ok = $("ok2");
  const email = $("m1").value.trim();
  const message = $("m2").value.trim();

  if (!email || !message) {
    showMessage(ok, "Veuillez remplir tous les champs.");
    return;
  }

  const submitButton = event.submitter;
  if (submitButton) submitButton.disabled = true;

  try {
    await apiRequest(`${API_URL}/contact`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ email, message })
    });

    showMessage(
      ok,
      "Votre message a été envoyé avec succès.",
      true
    );

    $("msg").reset();
  } catch (error) {
    showMessage(ok, error.message);
    console.error("Erreur de contact :", error);
  } finally {
    if (submitButton) submitButton.disabled = false;
  }
});

// 10. Chatbot
const chatToggle = $("chatToggle");
const chatBox = $("chatBox");
const closeChat = $("closeChat");
const chatForm = $("chatForm");
const chatInp = $("chatInp");
const chatMsgs = $("chatMsgs");
const chatHistory = [];

chatToggle.addEventListener("click", () => {
  chatBox.classList.toggle("open");

  if (chatBox.classList.contains("open")) {
    chatInp.focus();
  }
});

closeChat.addEventListener("click", () => {
  chatBox.classList.remove("open");
});

function addChatMessage(message, className) {
  const div = document.createElement("div");
  div.className = className;
  div.dir = "auto";
  div.textContent = message;

  chatMsgs.appendChild(div);
  chatMsgs.scrollTop = chatMsgs.scrollHeight;

  return div;
}

chatForm.addEventListener("submit", async event => {
  event.preventDefault();

  const message = chatInp.value.trim();
  if (!message) return;

  addChatMessage(message, "msg-user");
  chatInp.value = "";

  const loading = addChatMessage(
    "Je prépare ma réponse...",
    "msg-bot"
  );

  const submitButton = chatForm.querySelector("button");
  submitButton.disabled = true;

  try {
    const data = await apiRequest(`${API_URL}/chatbot`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ message, history: chatHistory })
    });

    loading.textContent =
      data.reply || "Je n'ai pas de réponse pour le moment.";

    chatHistory.push(
      { role: "user", content: message },
      { role: "assistant", content: loading.textContent }
    );
    while (chatHistory.length > 10) chatHistory.shift();
  } catch (error) {
    loading.textContent =
      "Impossible de contacter le serveur. Réessayez.";
    console.error("Erreur chatbot :", error);
  } finally {
    submitButton.disabled = false;
    chatInp.focus();
    chatMsgs.scrollTop = chatMsgs.scrollHeight;
  }
});

// 11. Démarrer l'application
reveal(document.querySelectorAll(
  ".why > div, .cities span, .contact > *, #flotte .t, #flotte .lead, #pourquoi .t"
));
fetchCars();
