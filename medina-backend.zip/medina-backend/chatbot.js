// Chatbot multilingue simple (sans API externe).
// Langues : fr (français), en (anglais), tn (derja en lettres latines), ar (arabe).
// Pour ajouter un mot ou une langue, modifiez seulement INTENTS / MARKERS / REPLIES.

const LANGS = ["fr", "en", "tn", "ar"];
// "any" : mots valables dans toutes les langues (ne servent pas à détecter la langue).
const MATCH_GROUPS = [...LANGS, "any"];

// Mots-clés par intention. "mot*" = commence par "mot" (réservation, reserver...).
// L'ordre compte : la première intention trouvée gagne (salutation en dernier).
const INTENTS = [
  {
    name: "price",
    keywords: {
      fr: ["prix", "tarif*", "combien", "cout*", "coute*", "cher"],
      en: ["price*", "cost*", "how much", "rate*", "cheap", "expensive"],
      tn: ["9adech", "9addech", "9addeh", "9adh", "bch7al", "bech7al", "ch7al", "chhal", "taman", "thaman", "themen", "ghali", "ghalya", "rkhis"],
      ar: ["سعر", "اسعار", "تسعيره", "بكم", "قداش", "قدايش", "شحال", "بشحال", "ثمن", "تكلفه", "كم سعر", "كم ثمن", "غالي"]
    }
  },
  {
    name: "booking",
    keywords: {
      fr: ["reserv*", "louer", "location", "loue*"],
      en: ["book*", "rent*", "reserv*", "hire"],
      tn: ["n7ajez", "nhajez", "7ajz", "hajz", "7ajez", "nkri", "nekri", "kri", "kraya", "n3amer", "nloui"],
      ar: ["حجز", "احجز", "حجوزات", "كراء", "اكري", "نكري", "اكتري", "ايجار", "استئجار", "استاجر"]
    }
  },
  {
    name: "city",
    keywords: {
      any: ["sfax", "tunis", "sousse", "monastir", "hammamet", "djerba", "hotel"],
      fr: ["ville*", "retrait", "aeroport", "gare"],
      en: ["city", "cities", "airport", "pickup", "pick-up", "pick up", "where", "station"],
      tn: ["blasa", "mdina", "win", "wine", "jerba", "mtar", "matar"],
      ar: ["مدينه", "مدن", "صفاقس", "تونس", "سوسه", "المنستير", "الحمامات", "جربه", "مطار", "وين", "اين", "فندق"]
    }
  },
  {
    name: "contact",
    keywords: {
      fr: ["contact*", "telephone", "tel", "appeler", "joindre", "whatsapp", "mail", "email"],
      en: ["contact*", "phone", "call", "email", "whatsapp", "mail"],
      tn: ["ra9m", "ra9em", "numro", "nummero", "ntassel", "ntaasel", "ncontacti", "telifoun", "tilifoun", "talifoun"],
      ar: ["اتصال", "اتصل", "تواصل", "هاتف", "رقم", "تليفون", "واتساب", "بريد", "ايميل"]
    }
  },
  {
    name: "bye",
    keywords: {
      fr: ["au revoir", "a bientot", "bonne journee", "adieu"],
      en: ["bye", "goodbye", "see you", "good night"],
      tn: ["bslema", "besslema", "bsslema", "bslama", "besslama", "yaatik essaha bslema"],
      ar: ["مع السلامه", "بسلامه", "الى اللقاء", "الي اللقاء"]
    }
  },
  {
    name: "thanks",
    keywords: {
      fr: ["merci", "mercii"],
      en: ["thanks", "thank*", "thx"],
      tn: ["ya3tik", "yaatik", "ya3tikom", "mersi", "mrc", "saha", "sa7a", "barakallah"],
      ar: ["شكرا", "شكر", "يعطيك", "يعطيكم", "بارك"]
    }
  },
  {
    name: "greeting",
    keywords: {
      fr: ["bonjour", "bonsoir", "salut", "coucou"],
      en: ["hello", "hi", "hey", "good morning", "good evening"],
      tn: ["ahla", "ahlan", "aslema", "asslema", "3aslema", "3asslema", "salem", "marhba", "mar7ba", "slm"],
      ar: ["مرحبا", "اهلا", "السلام", "سلام", "صباح الخير", "مساء الخير", "عسلامه", "هلا"]
    }
  }
];

// Mots courants qui aident à reconnaître la langue (alphabet latin).
const MARKERS = {
  fr: ["je", "vous", "nous", "est", "quel", "quelle", "quels", "pour", "les", "des", "une", "un", "le", "la", "du", "avec", "voiture", "voitures", "jour", "svp", "stp", "comment", "ou", "peux", "voudrais", "veux"],
  en: ["the", "is", "are", "what", "how", "do", "does", "you", "can", "i", "my", "car", "cars", "much", "per", "day", "please", "want", "need", "would", "like", "where"],
  tn: ["el", "w", "ya", "3andek", "3andi", "3andkom", "nheb", "n7eb", "nheb", "nlawej", "nel9a", "chnoua", "chnowa", "chnya", "chneya", "kifech", "kifah", "kifeh", "3lech", "mta3", "mte3", "barcha", "behi", "bahi", "famma", "fama", "lyoum", "ena", "enti", "mouch", "bech", "bch", "9olli", "9oul", "wini", "inti", "ken"],
  ar: []
};

const REPLIES = {
  price: {
    fr: "Nos tarifs commencent à 90 DT par jour. Consultez les voitures disponibles sur notre site.",
    en: "Our prices start at 90 DT per day. Take a look at the available cars on our website.",
    tn: "El as3ar tebda men 90 DT lel nhar. Chouf el voitures el mawjouda f site mte3na.",
    ar: "تبدأ أسعارنا من 90 دينارا في اليوم. يمكنك الاطلاع على السيارات المتوفرة في موقعنا."
  },
  booking: {
    fr: "Pour réserver, choisissez une voiture, sélectionnez les dates, remplissez vos coordonnées et confirmez la réservation.",
    en: "To book, choose a car, select your dates, fill in your details and confirm the reservation.",
    tn: "Bech t7ajez, ikhtar voiture, e5tar les dates, 3ammer les coordonnées mte3ek w a3mel confirmation lel réservation.",
    ar: "للحجز، اختر سيارة، حدد التواريخ، املأ بياناتك ثم أكد الحجز."
  },
  city: {
    fr: "Indiquez votre ville dans le formulaire de réservation. Contactez notre équipe pour confirmer la disponibilité.",
    en: "Select your pick-up city in the booking form. Contact our team to confirm availability.",
    tn: "Ikhtar el ville mta3 el retrait f formulaire el réservation. Contactina bech nconfirmou el disponibilité.",
    ar: "اختر مدينة الاستلام في نموذج الحجز. تواصل مع فريقنا لتأكيد التوفر."
  },
  contact: {
    fr: "Vous pouvez nous envoyer un message via le formulaire de contact du site.",
    en: "You can send us a message through the contact form on the website.",
    tn: "Tnajem tab3athlena message men formulaire el contact f site.",
    ar: "يمكنك مراسلتنا عبر نموذج الاتصال في الموقع."
  },
  bye: {
    fr: "Au revoir ! À bientôt chez Medina Cars.",
    en: "Goodbye! See you soon at Medina Cars.",
    tn: "Besslema! Nchoufouk bientôt f Medina Cars.",
    ar: "إلى اللقاء! نراك قريبا في ميدينا كارز."
  },
  thanks: {
    fr: "Avec plaisir ! Nous sommes là pour vous aider.",
    en: "You're welcome! We're here to help.",
    tn: "Bil 3afw! Ihna hne bech na3awnouk.",
    ar: "عفوا! نحن هنا لمساعدتك."
  },
  greeting: {
    fr: "Bonjour ! Bienvenue dans notre agence de location. Comment pouvons-nous vous aider ?",
    en: "Hello! Welcome to our car rental agency. How can we help you?",
    tn: "Ahla bik! Marhba bik f agence mta3 el location. Kifech nnajem na3awnek?",
    ar: "مرحبا! أهلا بك في وكالة كراء السيارات. كيف يمكننا مساعدتك؟"
  },
  fallback: {
    fr: "Je peux vous aider pour les prix, les réservations et les informations de location. Posez-moi votre question !",
    en: "I can help with prices, bookings and rental information. Ask me anything!",
    tn: "Nnajem na3awnek f el as3ar, el 7ajz w ma3loumet el location. Es2elni!",
    ar: "يمكنني مساعدتك في الأسعار والحجز ومعلومات الكراء. اطرح سؤالك!"
  }
};

// Minuscules, sans accents latins ni voyelles arabes, lettres arabes unifiées.
function normalize(text) {
  return String(text)
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f\u064B-\u065F\u0670\u0640]/g, "")
    .replace(/[أإآٱ]/g, "ا")
    .replace(/ة/g, "ه")
    .replace(/ى/g, "ي")
    .replace(/\s+/g, " ")
    .trim();
}

const hasArabic = text => /[\u0600-\u06FF]/.test(text);

function makeMatcher(norm) {
  const tokens = norm.split(/[^a-z0-9]+/).filter(Boolean);
  const padded = ` ${tokens.join(" ")} `;

  return keyword => {
    if (hasArabic(keyword)) return norm.includes(keyword);
    if (keyword.endsWith("*")) {
      const stem = keyword.slice(0, -1);
      return tokens.some(token => token.startsWith(stem));
    }
    return padded.includes(` ${keyword} `);
  };
}

// Normaliser une seule fois les mots-clés et marqueurs au démarrage.
INTENTS.forEach(intent => {
  MATCH_GROUPS.forEach(lang => {
    intent.keywords[lang] = (intent.keywords[lang] || []).map(normalize);
  });
});
LANGS.forEach(lang => {
  MARKERS[lang] = MARKERS[lang].map(normalize);
});

function detectLanguage(norm, matches) {
  if (hasArabic(norm)) return "ar";

  const match = makeMatcher(norm);
  const score = { fr: 0, en: 0, tn: 0, ar: 0 };

  LANGS.forEach(lang => {
    MARKERS[lang].forEach(word => { if (match(word)) score[lang] += 1; });
  });
  matches.forEach(lang => { score[lang] += 1; });

  // En cas d'égalité : fr, puis en, puis tn.
  return ["fr", "en", "tn"].reduce(
    (best, lang) => (score[lang] > score[best] ? lang : best),
    "fr"
  );
}

function getReply(message) {
  const norm = normalize(message);
  const match = makeMatcher(norm);

  let intentName = "fallback";
  const matchedLangs = [];

  for (const intent of INTENTS) {
    const found = MATCH_GROUPS.filter(group =>
      intent.keywords[group].some(match)
    );

    if (found.length > 0) {
      intentName = intent.name;
      matchedLangs.push(...found.filter(group => group !== "any"));
      break;
    }
  }

  const lang = detectLanguage(norm, matchedLangs);
  return { lang, intent: intentName, reply: REPLIES[intentName][lang] };
}

module.exports = { getReply, normalize };
