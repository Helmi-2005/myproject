
const express = require("express");
const sqlite3 = require("sqlite3").verbose();
const path = require("path");
const cors = require("cors");
const { getReply } = require("./chatbot");
const { askClaude, isEnabled } = require("./ai");

const fs = require("fs");
const crypto = require("crypto");

// Charge le fichier .env (clé API) sans dépendance supplémentaire
try {
  fs.readFileSync(path.join(__dirname, ".env"), "utf8")
    .split(/\r?\n/)
    .forEach(line => {
      const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
      if (m && !line.trim().startsWith("#") && !(m[1] in process.env)) {
        process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
      }
    });
} catch {}

const app = express();
const PORT = 3000;
const DB_PATH = path.join(__dirname, "database.db");

const publicCors = cors();
app.use((req, res, next) =>
  req.path.startsWith("/api/admin") ? next() : publicCors(req, res, next)
);
app.use(express.json({ limit: "20kb" }));
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, "public")));

const db = new sqlite3.Database(DB_PATH, (err) => {
  if (err) {
    console.error("Erreur SQLite :", err.message);
    process.exit(1);
  }
  console.log("Base de données SQLite connectée.");
});

db.serialize(() => {
  db.run("PRAGMA foreign_keys = ON");

  db.run(`
    CREATE TABLE IF NOT EXISTS cars (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      type TEXT NOT NULL,
      specs TEXT NOT NULL,
      price REAL NOT NULL CHECK(price > 0),
      color TEXT NOT NULL DEFAULT "#2678a5"
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS reservations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      car_id INTEGER NOT NULL,
      city TEXT NOT NULL,
      start_date TEXT NOT NULL,
      end_date TEXT NOT NULL,
      client_name TEXT NOT NULL,
      phone TEXT NOT NULL,
      total_price REAL NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (car_id) REFERENCES cars(id)
    )
  `);

  // Anciennes bases : ajouter la colonne status si elle manque
  db.all("PRAGMA table_info(reservations)", (err, columns) => {
    if (!err && !columns.some(c => c.name === "status")) {
      db.run("ALTER TABLE reservations ADD COLUMN status TEXT NOT NULL DEFAULT 'pending'");
    }
  });

  db.run(`
    CREATE TABLE IF NOT EXISTS contacts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT NOT NULL,
      message TEXT NOT NULL,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )
  `);

  db.get("SELECT COUNT(*) AS total FROM cars", (err, row) => {
    if (err) {
      console.error(err.message);
      return;
    }

    if (row.total === 0) {
      const cars = [
        ["Dacia Logan", "Berline", "5 places · Manuelle · Essence", 90, "#2678a5"],
        ["Renault Clio", "Citadine", "5 places · Manuelle · Essence", 110, "#d44d4d"],
        ["Peugeot 208", "Citadine", "5 places · Automatique · Essence", 130, "#4b9b76"],
        ["Volkswagen Golf", "Compacte", "5 places · Manuelle · Diesel", 160, "#7b70c9"],
        ["Hyundai i20", "Citadine", "5 places · Manuelle · Essence", 100, "#d79a35"],
        ["Toyota Corolla", "Berline", "5 places · Automatique · Hybride", 180, "#3b8790"],
        ["Kia Sportage", "SUV", "5 places · Automatique · Diesel", 230, "#596675"],
        ["Peugeot 3008", "SUV", "5 places · Automatique · Diesel", 250, "#a86c43"]
      ];

      const stmt = db.prepare(`
        INSERT INTO cars (name, type, specs, price, color)
        VALUES (?, ?, ?, ?, ?)
      `);

      cars.forEach(car => stmt.run(car));
      stmt.finalize(() => console.log("Voitures de démonstration ajoutées."));
    }
  });
});

// Vérification des dates au format YYYY-MM-DD
function validDate(value) {
  if (typeof value !== "string" ||
      !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    return false;
  }

  const date = new Date(value + "T00:00:00Z");
  return !Number.isNaN(date.getTime()) &&
    date.toISOString().slice(0, 10) === value;
}

function daysBetween(start, end) {
  const a = Date.parse(start + "T00:00:00Z");
  const b = Date.parse(end + "T00:00:00Z");
  return Math.round((b - a) / 86400000);
}

// GET : récupérer les voitures
app.get("/api/cars", (req, res) => {
  db.all(
    "SELECT id, name, type, specs, price, color FROM cars ORDER BY id",
    (err, rows) => {
      if (err) {
        console.error(err.message);
        return res.status(500).json({
          success: false, message: "Erreur de base de données."
        });
      }
      res.json(rows);
    }
  );
});

// POST : enregistrer une réservation
app.post("/api/reservations", (req, res) => {
  const {
    car_id, city, start_date, end_date,
    client_name, phone
  } = req.body || {};

  const carId = Number(car_id);
  const name = typeof client_name === "string"
    ? client_name.trim() : "";
  const cityName = typeof city === "string"
    ? city.trim() : "";
  const tel = typeof phone === "string"
    ? phone.trim() : "";

  if (!Number.isInteger(carId) || carId < 1) {
    return res.status(400).json({
      success: false, message: "Voiture invalide."
    });
  }

  if (!name || name.length > 100 ||
      !cityName || cityName.length > 100) {
    return res.status(400).json({
      success: false,
      message: "Nom et ville obligatoires."
    });
  }

  if (!/^[0-9+\s()-]{8,20}$/.test(tel)) {
    return res.status(400).json({
      success: false,
      message: "Numéro de téléphone invalide."
    });
  }

  if (!validDate(start_date) || !validDate(end_date)) {
    return res.status(400).json({
      success: false, message: "Format de date invalide."
    });
  }

  const today = new Date().toISOString().slice(0, 10);

  if (start_date < today || daysBetween(start_date, end_date) < 1) {
    return res.status(400).json({
      success: false,
      message: "Les dates de réservation sont invalides."
    });
  }

  db.get(
    "SELECT id, name, price FROM cars WHERE id = ?",
    [carId],
    (err, car) => {
      if (err) {
        return res.status(500).json({
          success: false, message: "Erreur de base de données."
        });
      }

      if (!car) {
        return res.status(404).json({
          success: false, message: "Voiture introuvable."
        });
      }

      const days = daysBetween(start_date, end_date);
      const total = days * car.price;

      db.run(
        `INSERT INTO reservations
        (car_id, city, start_date, end_date,
         client_name, phone, total_price)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [carId, cityName, start_date, end_date,
         name, tel, total],
        function (insertErr) {
          if (insertErr) {
            console.error(insertErr.message);
            return res.status(500).json({
              success: false,
              message: "Impossible d'enregistrer la réservation."
            });
          }

          console.log(
            `Nouvelle réservation #${this.lastID} : ${name} (${tel}), ` +
            `${car.name}, ${start_date} → ${end_date}, ${total} DT`
          );

          res.status(201).json({
            success: true,
            reservationId: this.lastID,
            car: car.name,
            days,
            total_price: total,
            message: "Réservation enregistrée."
          });
        }
      );
    }
  );
});

// POST : enregistrer un message de contact
app.post("/api/contact", (req, res) => {
  const email = typeof req.body?.email === "string"
    ? req.body.email.trim() : "";
  const message = typeof req.body?.message === "string"
    ? req.body.message.trim() : "";

  if (
    email.length > 254 ||
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
  ) {
    return res.status(400).json({
      success: false, message: "Adresse e-mail invalide."
    });
  }

  if (!message || message.length > 5000) {
    return res.status(400).json({
      success: false, message: "Message invalide."
    });
  }

  db.run(
    "INSERT INTO contacts (email, message) VALUES (?, ?)",
    [email, message],
    function (err) {
      if (err) {
        console.error(err.message);
        return res.status(500).json({
          success: false, message: "Erreur lors de l'envoi."
        });
      }

      res.status(201).json({
        success: true,
        messageId: this.lastID
      });
    }
  );
});

// Limite simple : 20 messages par minute et par adresse IP (protège le coût de l'API)
const chatHits = new Map();

function tooManyRequests(ip) {
  const now = Date.now();
  const hits = (chatHits.get(ip) || []).filter(t => now - t < 60000);
  hits.push(now);
  chatHits.set(ip, hits);
  return hits.length > 20;
}

function getCars() {
  return new Promise(resolve => {
    db.all(
      "SELECT name, type, specs, price FROM cars ORDER BY id",
      (err, rows) => resolve(err ? [] : rows)
    );
  });
}

// POST : chatbot (Claude si une clé API existe, sinon réponses par mots-clés)
app.post("/api/chatbot", async (req, res) => {
  const message = typeof req.body?.message === "string"
    ? req.body.message.trim() : "";

  if (!message || message.length > 1000) {
    return res.status(400).json({
      success: false,
      reply: "Veuillez saisir un message valide."
    });
  }

  if (isEnabled() && !tooManyRequests(req.ip)) {
    try {
      const reply = await askClaude({
        message,
        history: req.body.history,
        cars: await getCars()
      });
      return res.json({ success: true, reply, source: "ai" });
    } catch (error) {
      console.error("Erreur Claude :", error.message);
    }
  }

  // Plan B : chatbot par mots-clés
  const { reply, lang } = getReply(message);
  res.json({ success: true, reply, lang, source: "rules" });
});

// ---------- Administration (mot de passe : ADMIN_PASSWORD dans .env) ----------
const sha = value => crypto.createHash("sha256").update(String(value)).digest();
const safeEqual = (a, b) => crypto.timingSafeEqual(sha(a), sha(b));
const adminFails = new Map();

function adminAuth(req, res, next) {
  const password = process.env.ADMIN_PASSWORD;

  if (!password) {
    return res.status(503).send(
      "Administration désactivée : ajoutez ADMIN_PASSWORD dans le fichier .env " +
      "puis relancez le serveur."
    );
  }

  const now = Date.now();
  const fail = adminFails.get(req.ip) || { count: 0, since: now };
  if (now - fail.since > 15 * 60000) { fail.count = 0; fail.since = now; }

  if (fail.count >= 10) {
    return res.status(429).send("Trop de tentatives. Réessayez dans quelques minutes.");
  }

  const [scheme, encoded] = (req.headers.authorization || "").split(" ");
  let ok = false;

  if (scheme === "Basic" && encoded) {
    const decoded = Buffer.from(encoded, "base64").toString("utf8");
    const index = decoded.indexOf(":");
    ok = index > -1 &&
      safeEqual(decoded.slice(0, index), "admin") &&
      safeEqual(decoded.slice(index + 1), password);
  }

  if (!ok) {
    fail.count += 1;
    adminFails.set(req.ip, fail);
    res.set("WWW-Authenticate", 'Basic realm="Medina Cars Admin", charset="UTF-8"');
    return res.status(401).send("Authentification requise.");
  }

  adminFails.delete(req.ip);
  res.set("Cache-Control", "no-store");
  next();
}

app.get("/admin", adminAuth, (req, res) => {
  res.sendFile(path.join(__dirname, "admin", "index.html"));
});

app.get("/api/admin/reservations", adminAuth, (req, res) => {
  db.all(
    `SELECT r.*, c.name AS car_name
     FROM reservations r LEFT JOIN cars c ON c.id = r.car_id
     ORDER BY r.id DESC`,
    (err, rows) => {
      if (err) {
        console.error(err.message);
        return res.status(500).json({ success: false, message: "Erreur de base de données." });
      }
      res.json(rows);
    }
  );
});

app.patch("/api/admin/reservations/:id", adminAuth, (req, res) => {
  const id = Number(req.params.id);
  const status = req.body?.status;

  if (!Number.isInteger(id) || !["pending", "confirmed", "cancelled"].includes(status)) {
    return res.status(400).json({ success: false, message: "Données invalides." });
  }

  db.run("UPDATE reservations SET status = ? WHERE id = ?", [status, id], function (err) {
    if (err) {
      console.error(err.message);
      return res.status(500).json({ success: false, message: "Erreur de base de données." });
    }
    if (this.changes === 0) {
      return res.status(404).json({ success: false, message: "Réservation introuvable." });
    }
    res.json({ success: true });
  });
});

app.get("/api/admin/contacts", adminAuth, (req, res) => {
  db.all("SELECT * FROM contacts ORDER BY id DESC", (err, rows) => {
    if (err) {
      console.error(err.message);
      return res.status(500).json({ success: false, message: "Erreur de base de données." });
    }
    res.json(rows);
  });
});

// Route d'accueil
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// Routes API inconnues
app.use("/api", (req, res) => {
  res.status(404).json({
    success: false, message: "Route API introuvable."
  });
});

// Gestion des erreurs
app.use((err, req, res, next) => {
  console.error("Erreur :", err.type || "", err.message);

  let status = err.status || 500;
  let message = "Une erreur est survenue.";

  if (err.type === "entity.parse.failed") {
    status = 400;
    message = "JSON invalide.";
  } else if (err.type === "entity.too.large") {
    status = 413;
    message = "Requête trop volumineuse.";
  }

  res.status(status).json({ success: false, message });
});

app.listen(PORT, () => {
  console.log(`Serveur lancé : http://localhost:${PORT}`);
});